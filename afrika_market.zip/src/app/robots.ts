import type { MetadataRoute } from "next";

const BASE = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin", "/vendeur", "/compte", "/api/", "/checkout", "/confirmation"],
      },
    ],
    sitemap: `${BASE}/sitemap.xml`,
  };
}
