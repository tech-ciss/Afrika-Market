# 🎤 Préparation de la soutenance — AFRIKA MARKET

Réponses courtes aux questions du cahier des charges (§40), avec l'endroit du code à montrer.

## Architecture

**Pourquoi Next.js ?** Rendu serveur du catalogue (SEO, performance sur connexion limitée), Server Actions pour les mutations, groupes de routes pour séparer les espaces, déploiement Vercel natif.

**Pourquoi Prisma ?** Schéma typé de bout en bout, migrations versionnées, transactions interactives pour les opérations critiques (création de commande, stock).

**Pourquoi séparer la logique métier des composants ?** Les règles (promo, livraison, stock, statuts) sont des fonctions pures dans `src/lib/services/`, testables sans base ni navigateur et réutilisables par plusieurs points d'entrée.

**Pourquoi des Server Actions ?** Pas d'API REST à maintenir pour les formulaires ; chaque action suit la chaîne authentification → autorisation → Zod → service. Les Route Handlers ne servent que pour les appels extérieurs (webhook, cron, Auth.js).

## Paiement

**Pourquoi une abstraction ?** `PaymentProvider` isole le prestataire : ajouter Wave ou CinetPay = un adapter, sans toucher à la logique de commande (`payment.service.ts`).

**Pourquoi ne pas croire le retour du navigateur ?** Le client peut revenir sur la page sans avoir payé, ou fermer l'onglet après avoir payé. Seul un évènement signé (webhook) ou une vérification auprès du prestataire fait passer à `PAID`. `/confirmation` est en lecture seule.

**Webhook reçu deux fois ?** `markOrderPaid` fait un `updateMany WHERE status = PENDING_PAYMENT` : une seule requête change l'état, l'autre est ignorée. Testé dans `tests/payment.test.ts`.

**Paiement interrompu ?** La commande reste `PENDING_PAYMENT` puis expire (`/api/cron/expire-orders`, `UNPAID_ORDER_TTL_MINUTES`) : annulation et restitution du stock.

**Comment sécuriser le webhook ?** Signature HMAC-SHA256, comparaison avec `timingSafeEqual`, montant comparé à `order.total`, secret obligatoire en production, rate limiting.

## Stock

**Comment éviter une double vente de la dernière unité ?** `decrementStock()` fait `updateMany WHERE stock >= quantité` dans la transaction de création : la base ne laisse passer qu'une seule requête, les autres échouent et la transaction est annulée. Voir `tests/stock-concurrent.test.ts`.

**Pourquoi une transaction ?** Commande, lignes, paiement, livraison et décrément de stock doivent réussir ou échouer ensemble.

**Quand le stock est-il décrémenté ?** À la création de la commande (réservation), restitué en cas d'annulation, d'échec ou d'expiration. Choix assumé : c'est ce qui élimine la vente simultanée.

## Marketplace

**Comment empêcher un producteur de modifier les données d'un autre ?** `requireRole()` puis filtrage par `producerId` sur chaque lecture et écriture (ex. `ownedProduct`). Un identifiant forgé ne retourne rien.

**Comment valider un producteur ?** Statuts `PENDING → APPROVED / REJECTED / SUSPENDED` gérés depuis `/admin/producteurs` ; un producteur non approuvé ne publie pas.

**Comment calculer les ventes d'un producteur ?** Les `OrderItem` portent `producerId` (snapshot) : agrégation sur les lignes de commandes payées, dans `producer.service.ts`.

## Livraison

**Prix selon une zone ?** `computeShippingFee()` : retrait gratuit, sinon tarif de la `DeliveryZone`, gratuit au-delà du seuil ou avec un code `FREE_SHIPPING`.

**Ajouter une nouvelle ville ?** Créer une zone depuis `/admin/zones` ; aucune modification de code ni déploiement.

**Évoluer vers plusieurs pays ?** Chaque zone référence un `Country` ; activation d'un pays dans `/admin/parametres`. Les montants sont en `Int` avec une colonne `currency` déjà présente.

## Produit

**Pourquoi afficher l'origine ?** C'est la valeur du projet : pays, région, producteur, méthode et période de récolte créent le lien entre consommateur et producteur.

**Pourquoi un snapshot dans `OrderItem` ?** Nom, prix, SKU, producteur et origine sont copiés : modifier ou supprimer un produit ne réécrit jamais l'historique d'une commande ni une facture.

## Sécurité (questions probables)

**Comment sont protégées les routes privées ?** Deux couches : `middleware.ts` (JWT, avant rendu) puis `requireRole()` dans chaque page et action.

**Rate limiting ?** Sur connexion, inscription, contact, newsletter, codes promo et webhook. Limite assumée : stockage en mémoire (par instance serverless) ; solution : Redis/Upstash.

**Le mode sandbox est-il dangereux ?** Il ne débite personne. Il est assumé pour la démonstration ; en production réelle, `PAYMENT_PROVIDER` pointe vers un vrai prestataire et la page de simulation n'est plus utilisée.

## Démonstration conseillée (5 minutes)

1. Accueil → fiche produit (origine, producteur) → ajout au panier.
2. Checkout en tant qu'invité, zone Abidjan, Wave sandbox → confirmation.
3. Connexion producteur : la commande apparaît sur ses produits uniquement.
4. Connexion admin : tableau de bord, validation d'un producteur, modération d'un avis.
5. Montrer `tests/stock-concurrent.test.ts` et lancer `npm run test:e2e`.
